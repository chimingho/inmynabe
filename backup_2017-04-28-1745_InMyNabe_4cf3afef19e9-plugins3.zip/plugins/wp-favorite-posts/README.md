# WP Favorite Posts

WP Favorite Posts is a WordPress plugin [http://wordpress.org/plugins/wp-favorite-posts](http://wordpress.org/plugins/wp-favorite-posts)

* **Contributors**: [@hberberoglu](https://github.com/hberberoglu), [@mustafauysal](https://github.com/mustafauysal), [@mtedwards](https://github.com/mtedwards), [@mirkolofio](https://github.com/mirkolofio)
* **Contributing**: Contributions are more than welcome. Please submit pull requests against the [master branch](https://github.com/hberberoglu/wp-favorite-posts). Thanks!
