<div class="updated se-updated" id="se-top-global-notice" >
	<div class="se-dismiss"><a href="<?php echo $close_url; ?>">Dismiss and go to settings</a></div>
	<h3><?php echo $notice['title']; ?></h3>
	<p class="se-about-description"><?php echo $notice['message']; ?></p>
</div>

