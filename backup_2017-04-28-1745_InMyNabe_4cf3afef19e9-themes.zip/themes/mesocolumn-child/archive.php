<?php get_header();
$query = get_queried_object();
//do_wp_debug(__FILE__, array('headline', $query));
$cat_id = isset($query->term_id)? $query->term_id: 'none';
?>

<?php do_action( 'bp_before_content' ) ?>

<?php if(is_author()){get_template_part( 'lib/templates/post-meta-cpt-link-addon' );} ?>

<!-- CONTENT START -->
<div class="content">
<div class="content-inner">

<?php do_action( 'bp_before_blog_home' ) ?>

<!-- POST ENTRY START -->
<div id="post-entry" class="archive_tn_cat_color_<?php echo $cat_id; ?>">
<div class="post-entry-inner">

<?php do_action( 'bp_before_blog_entry' ); ?>

<?php get_template_part( 'content-post-type-mixed' ); ?>

<?php get_template_part( 'lib/templates/paginate' ); ?>

<?php do_action( 'bp_after_blog_entry' ); ?>

</div>
</div>
<!-- POST ENTRY END -->

<?php do_action( 'bp_after_blog_home' ) ?>

</div><!-- CONTENT INNER END -->
</div><!-- CONTENT END -->

<?php do_action( 'bp_after_content' ) ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>