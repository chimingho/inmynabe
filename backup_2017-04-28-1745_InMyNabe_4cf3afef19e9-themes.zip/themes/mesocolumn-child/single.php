<?php global $gmw; 

?>
<?php get_header(); ?>

<?php do_action( 'bp_before_content' ); ?>
<!-- CONTENT START -->
<div class="content">
<div class="content-inner">

<?php do_action( 'bp_before_blog_home' ); ?>

<!-- POST ENTRY START -->
<div id="post-entry">

<div class="post-entry-inner">

<?php do_action( 'bp_before_blog_entry' ); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<?php do_action( 'bp_before_blog_post' ); ?>

<!-- POST START -->
<article <?php post_class('post-single'); ?> id="post-<?php the_ID(); ?>" <?php do_action('bp_article_start'); ?>>

<div class="post-top">
<h1 class="post-title entry-title" <?php do_action('bp_article_post_title'); ?>><?php the_title(); ?></h1>
<?php get_template_part( 'lib/templates/post-meta' ); ?>
<?php get_template_part( 'lib/templates/post-meta-cpt-link-addon' ); ?>
</div>

<?php do_action( 'bp_before_post_content' ); ?>

<div class="post-content">

<?php $get_ads_single_top = get_theme_mod('ads_single_top'); if($get_ads_single_top != '') { ?>
<div class="adsense-single adtop"><?php echo stripcslashes(do_shortcode($get_ads_single_top)); ?></div>
<?php } ?>
<div class="entry-content" <?php do_action('bp_article_post_content'); ?>>
  <!--cvh--> 
  <?php if ( has_post_thumbnail() ) { ?>
    <div class="post-thumbnail col-1-3 display-inlineblock float-right">
      <?php the_post_thumbnail( array( $gmw['search_results']['featured_image']['width'], $gmw['search_results']['featured_image']['height'] ) ); ?>
    </div>
  <?php } elseif (!empty($post->ASIN)) { ?>
    <div class="post-thumbnail col-1-3 display-inlineblock float-right">
      <?php echo get_amazon_product_template( array('asin'=> $post->ASIN, 'template'=> 'image', 'post_type'=>$post->post_type)); ?>
      <div class="jdx-btn jdx-btn-orange">
	    <?php echo get_amazon_product_template( array('asin'=> $post->ASIN, 'template'=> 'product link', 'post_type'=>$post->post_type)); ?>
      </div>
    </div>
  <?php } else { ?>
    <i class="fa fa-picture-o no-post-thumbnail col-1-3 display-inlineblock float-right"></i>
  <?php } ?>

  <div class="short_descript"><strong class="list-single-label">Owner Description</strong><?php if(has_excerpt()){the_excerpt( __('...more &raquo;','mesocolumn')); } else{echo '<br><br>';} ?></div>
  <div class="long_descript"><strong class="list-single-label">Detail</strong><?php the_content( __('...more &raquo;','mesocolumn') ); ?>
    <?php 
      switch ($post->post_type) {
      case 'recipe':
        get_template_part( 'lib/templates/post-gf-entry-recipe' );
        break;
      default:
      }?>
  </div>
  <!--cvh--> 
</div>
<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>

<?php $get_ads_single_bottom = get_theme_mod('ads_single_bottom'); if($get_ads_single_bottom != '') { ?>
<div class="adsense-single adbottom"><?php echo stripcslashes(do_shortcode($get_ads_single_bottom)); ?></div>
<?php } ?>

</div>

<?php do_action( 'bp_after_post_content' ); ?>

<?php get_template_part( 'lib/templates/post-meta', 'bottom' ); ?>

<?php $get_related = get_theme_mod('related_on'); if($get_related == 'enable'):
get_template_part( 'lib/templates/related' );
endif
?>

</article>
<!-- POST END -->

<?php do_action( 'bp_after_blog_post' ); ?>

<?php if( function_exists('dez_set_wp_post_view') ){ dez_set_wp_post_view( get_the_ID() ); } ?>

<?php endwhile; ?>

<?php
$get_author_bio = get_theme_mod('author_bio_on'); if($get_author_bio == 'enable'):
get_template_part( 'lib/templates/author-bio' );
endif
?>

<?php comments_template(); ?>

<?php else : ?>

<?php get_template_part( 'lib/templates/result' ); ?>

<?php endif; ?>

<?php get_template_part( 'lib/templates/paginate' ); ?>

<?php do_action( 'bp_after_blog_entry' ); ?>
</div>
</div>
<!-- POST ENTRY END -->

<?php do_action( 'bp_after_blog_home' ); ?>

</div><!-- CONTENT INNER END -->
  
<!-- chv: ads code at page bottom -->  
<div style="width:100%; display:inline-block;">
<?php 
  switch ($post->post_type) {
  case 'book':
    $search_phrase = get_amazon_product_template( array('asin'=> $post->ASIN, 'template'=> 'book author', 'post_type'=>$post->post_type));
    echo do_shortcode('[sc name="az_search" search_phrase="'.$search_phrase.'" default_category="Books"]'); 
	break;
  default:
    if(has_tag('', $post->id)){
      $tags = get_the_tags($post->id);
      $search_phrase = implode( ',', array_map( function( $tag ){
         return $tag->name;
      }, get_the_tags($post->id) ) );
      
    }else{
      $search_phrase = preg_replace( '/\d/', '', $post->post_title);
      $search_phrase = preg_replace( array('/\s\s+/','/-/'), ' ', $search_phrase);
      $search_phrase = preg_replace( '/\s/', ',', $search_phrase);
    }
      
    //do_wp_debug(__FILE__, array('get_amazon_search_phrase', $search_phrase));
    echo do_shortcode('[sc name="az_search" search_phrase="'.$search_phrase.'" default_category="All"]'); 
  }
?>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US&adInstanceId=2dbd372e-2e21-47bf-adc2-1a3897627261&storeId=jadepex-20"></script>
</div>  


</div><!-- CONTENT END -->

<?php do_action( 'bp_after_content' ); ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>