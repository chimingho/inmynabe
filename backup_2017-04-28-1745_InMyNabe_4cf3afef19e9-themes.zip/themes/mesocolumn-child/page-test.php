<?php get_header(); ?>

<?php do_action( 'bp_before_content' ); ?>


<h1>Unit Test</h1>  
<?php 
  $rslt = jdx_get_post_follower(266);
  do_wp_debug(__FILE__, array('jdx_get_post_follower', $rslt));
  //$rslt[] = 2;  
  //do_wp_debug(__FILE__, array('jdx_get_post_follower', $rslt));
?>

<?php do_action( 'bp_after_content' ); ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>

