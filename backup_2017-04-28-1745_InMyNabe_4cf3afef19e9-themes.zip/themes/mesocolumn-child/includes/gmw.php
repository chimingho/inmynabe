<?php

/***
* GeoMyWp single post will show by post template or GravityView template 
* value: default, GravityView
*/
//define('SINGLE_POST_CUSTOM', true);

/***
* resrict BuddyPress Location tab accessibility
*/
function gmw_fl_modify_nav($args ) {
 	$access = bp_core_can_edit_settings();
	$args['show_for_displayed_user'] = $access;
	return $args;
}
add_filter( 'gmw_fl_setup_nav', 'gmw_fl_modify_nav');


function gmw_pt_search_custom( $clauses, $form) {

  //do_wp_debug(__FILE__, array('gmw_pt_search_custom START', $clauses, $form));
  global $wpdb;
  $user_lat =$form['your_lat'];
  $user_lng=$form['your_lng']; 
  $radius=$form['radius'];
  $units=$form['units_array']['radius'];
 
  $members = query_search_get_users_by_location($user_lat, $user_lng, $radius, $units);
  if(empty($members)){
    foreach($clauses as $key => &$val){$val="";}
    //$clauses['join'] = $clauses['groupby']= $clauses['orderby']= $clauses['distinct']= $clauses['having']= "";
    $clauses['where'] = " AND false";
    $clauses['fields'] = " * ";
    //do_wp_debug(__FILE__, array('gmw_pt_search_custom No Memeber', $clauses));
    return $clauses;
  }
//  $sql = $wpdb->prepare( "SELECT * FROM (
//                              SELECT *, ROUND( %d * acos( cos( radians( %s ) ) * cos( radians( fl.lat ) ) * cos( radians( fl.long ) - radians( %s ) ) + sin( radians( %s ) ) * sin( radians( fl.lat) ) ),1 ) as distance  
//                              FROM wppl_friends_locator ) as gmwlocations 
//                            where distance < %d",
//                           array( $units, $user_lat, $user_lng, $user_lat, $radius ) );

  //move distance calc into inner friends table 
  $clauses['join'] = 'INNER JOIN ('.query_search_get_users_by_location($user_lat, $user_lng, $radius, $units, true).') as gmwlocations ON wpii_posts.post_author = gmwlocations.member_id ';
  $clauses['fields'] = preg_replace("/ROUND(.*?)AS distance/", "distance", $clauses['fields']);

  
  $clauses['where'] = $wpdb->prepare(" AND $wpdb->posts.post_type in (%s) ", implode( "','", $form['search_form']['post_types'])); 
  $clauses['where'] .= $wpdb->prepare(" AND $wpdb->posts.post_author IN (%s) ", implode( "','", $members )); 
  //$clauses['join'] = "INNER JOIN (".$sql.") ON "; 
  //$clauses['fields'] = $wpdb->prepare("$wpdb->posts.*, gmwlocations.lat, gmwlocations.long, gmwlocations.street, gmwlocations.city, gmwlocations.state, gmwlocations.zipcode, gmwlocations.country, gmwlocations.address, gmwlocations.formatted_address, gmwlocations.map_icon, gmwlocations.distance");
  $clauses = query_search_by_bp_privacy($clauses, $form);
  do_wp_debug(__FILE__, array('gmw_pt_search_custom End', $clauses));
  return $clauses;
}
add_filter('gmw_pt_location_query_clauses','gmw_pt_search_custom', 10, 2);


/*
function query_search_by_distance( $clauses, $query) {

  global $wpdb;
  //get the user's current location ( lat/ lng )
  $user_lat = ( isset( $_COOKIE['gmw_lat'] ) ) ? urldecode($_COOKIE['gmw_lat']) : false;
  $user_lng = ( isset( $_COOKIE['gmw_lng'] ) ) ? urldecode($_COOKIE['gmw_lng']) : false;

  //abort if user's current location not exist
  if ( $user_lat == false || $user_lng == false )
    return $clauses;

  //set some values
  $radius  = 10; //can be any value
  $orderby = 'post_date desc'; //can be user with post_title, post_date, ID and so on...
  $units 	 = 3959; //3959 for miles or 6371 for kilometers

  // join the location table into the query
  //$clauses['join']   .= " INNER JOIN `{$wpdb->prefix}places_locator` gmwlocations ON $wpdb->posts.ID = gmwlocations.post_id ";
  $clauses['join']   .= " INNER JOIN wppl_friends_locator gmwlocations ON $wpdb->posts.post_author = gmwlocations.member_id ";

  // add the radius calculation and add the locations fields into the results
  $clauses['fields'] .= $wpdb->prepare( ", gmwlocations.formatted_address , ROUND( %d * acos( cos( radians( %s ) ) * cos( radians( gmwlocations.lat ) ) * cos( radians( gmwlocations.long ) - radians( %s ) ) + sin( radians( %s ) ) * sin( radians( gmwlocations.lat) ) ),1 ) AS distance",
                                       array( $units, $user_lat, $user_lng, $user_lat ) );
  $clauses['groupby'] = $wpdb->prepare( " $wpdb->posts.ID HAVING distance <= %d OR distance IS NULL", $radius );
  $clauses['orderby'] = $orderby;
  
  return $clauses;
  
}
*/
//add_filter('posts_clauses','query_search_by_distance', 10, 2);



/**
 * Add the distance of the post from the user's location into the title
 * Can be also added to the content using the_content instead
 * 
 * @param  $title the original title
 * @return the modified title
 **
 *  Add the_title filter above into the search results of
 *  WordPress main query. We dont want the to effect other queries on the page
 **
 * Remove the_title filter once the main query is done
 * @param $query
 */

function gmw_modify_the_tile_with_distance( $title ) {
  global $post;

  $distance = ' ( '.$post->distance.' mi )';
  $title .= $distance;

  return $title;

}

function gmw_add_the_title_filter( $query ){

  if( $query->is_main_query() ){	
    add_filter( 'the_title', 'gmw_modify_the_tile_with_distance' );
  }

}
//add_action( 'loop_start', 'gmw_add_the_title_filter' );

function gmw_remove_the_title_filter( $query ){

  if( $query->is_main_query() ){
    remove_filter( 'the_title', 'gmw_modify_the_tile_with_distance' );
  }

}
//add_action( 'loop_end', 'gmw_remove_the_title_filter' );

/**
* modify submit text
*/
function gmw_modify_submit_text( $labels, $gmw ) {

  $labels['search_form']['submit'] = '<i class="icon-search"></i>';

  return $labels;
}
//add_filter( 'gmw_set_labels', 'gmw_modify_submit_text', 50, 2 );

function gmw_modify_member_address_fields( $address, $post, $gmw ) {
  //do_wp_debug(__FILE__, array('gmw_modify_member_address_fields', $address, $post, $gmw));

  //modify the value 1 to the ID of the form that you modify
  //if ( $gmw['prefix'] != 'fl' || $gmw['ID'] != 1 )
  //    return $address;

  //"build" the address that you would like to display
  $address = $post->city;

  //return the new address
  return $address;	
}
add_filter( 'gmw_location_address', 'gmw_modify_member_address_fields', 10, 3 );

function gmw_modify_excerpt_content( $content, $post, $gmw) {
  //do_wp_debug(__FILE__, array('gmw_modify_excerpt_content', $content, $post, $gmw));
    
    //modify the value 1 to the ID of the form that you modify
    //if ( $gmw['prefix'] != 'fl' || $gmw['ID'] != 1 )
    //    return $address;
 
    //"build" the address that you would like to display
    if(isset($content))
      return;
  
    $content = the_excerpt();
 
    //return the new address
    return $content;	
}
//add_filter( 'gmw_except_content', 'gmw_modify_excerpt_content', 10, 3 );

function gmw_modify_taxonomy( $args, $gmw, $taxonomy ) {
	
	$args['echo'] = false;
	return $args;

}
add_filter( 'gmw_pt_dropdown_taxonomy_args', 'gmw_modify_taxonomy', 10, 3 );

add_filter( 'gmw_pt_search_query_args', 'gmw_modify_query', 10, 1);
function gmw_modify_query( $query_args) {
  $query_args['post_status'] = array('publish','logged-in','friends','only-me');
  $query_args['is_gmw_query']=true;
  do_wp_debug(__FILE__, array('gmw_modify_query', $query_args));
  return $query_args;
}


