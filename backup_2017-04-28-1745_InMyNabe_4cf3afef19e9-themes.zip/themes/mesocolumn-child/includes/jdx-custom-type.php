<?php
// Exit if accessed directly
if (!defined('ABSPATH'))
    exit;

class JDX_Custom_Type
{
	public static function get_posts_count( $post_type, $user_id, $post_status) {
    $query_args = array(
      'author'        => $user_id,
      'post_type'     => $post_type,
      'post_status'   => $post_status
    );
    $get_posts = new WP_Query;
    return count($get_posts->query($query_args));

	}  
}

?>