<?php 
function wpa_cpt_tags( $query ) {
    if ( $query->is_tag() && $query->is_main_query() ) {
        $query->set( 'post_type', array( 'post', 'club', 'book', 'plant', 'recipe', 'service', 'tool' ) );
    }
}
add_action( 'pre_get_posts', 'wpa_cpt_tags' );

/** customize login page
*   https://codex.wordpress.org/Customizing_the_Login_Form
*/

function my_login_logo() { ?>
<style type="text/css">
  #login h1 a, .login h1 a {
    background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/images/site-login-logo.png);
    padding-bottom: 30px;
  }
</style>
<?php }
add_action( 'login_enqueue_scripts', 'my_login_logo' );

function wp_custom_login_header() {
  get_header();
}
add_action( 'login_head', 'wp_custom_login_header' );

function wp_custom_login_footer() {
  get_footer();
}
add_action( 'login_footer', 'wp_custom_login_footer' );

function my_login_logo_url() {
  return home_url();
}
add_filter( 'login_headerurl', 'my_login_logo_url' );

function my_login_logo_url_title() {
  return 'In My Neighborhood';
}
add_filter( 'login_headertitle', 'my_login_logo_url_title' );


?>