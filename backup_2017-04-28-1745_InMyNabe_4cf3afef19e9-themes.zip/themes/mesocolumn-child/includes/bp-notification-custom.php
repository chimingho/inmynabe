<?php
/**
*   ref: https://webdevstudios.com/2015/10/06/buddypress-adding-custom-notifications/
*
*/

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) )
  exit;


function custom_filter_notifications_get_registered_components( $component_names = array() ) {
	// Force $component_names to be an array
	if ( ! is_array( $component_names ) ) {
		$component_names = array();
	}
	// Add 'custom' component to registered components array
	array_push( $component_names, 'custom' );
	// Return component's with 'custom' appended
	return $component_names;
}
add_filter( 'bp_notifications_get_registered_components', 'custom_filter_notifications_get_registered_components' );

// this gets the saved item id, compiles some data and then displays the notification
function custom_format_buddypress_notifications( $action, $item_id, $secondary_item_id, $total_items, $format = 'string' ) {
	// New custom notifications
	if ( 'insert_comment' === $action ) {
	
		$comment = get_comment( $item_id );
	
		$custom_title = $comment->comment_author . ' also commented on the post ' . get_the_title( $comment->comment_post_ID );
		$custom_link  = get_comment_link( $comment );
		$custom_text = $comment->comment_author . ' also commented on the post ' . get_the_title( $comment->comment_post_ID );
		// WordPress Toolbar
		if ( 'string' === $format ) {
			$return = apply_filters( 'custom_filter', '<a href="' . esc_url( $custom_link ) . '" title="' . esc_attr( $custom_title ) . '">' . esc_html( $custom_text ) . '</a>', $custom_text, $custom_link );
		// Deprecated BuddyBar
		} else {
			$return = apply_filters( 'custom_filter', array(
				'text' => $custom_text,
				'link' => $custom_link
			), $custom_link, (int) $total_items, $custom_text, $custom_title );
		}
		
		return $return;
		
	}
	
}
add_filter( 'bp_notifications_get_notifications_for_user', 'custom_format_buddypress_notifications', 10, 5 );

// this hooks to comment creation and saves the comment id
function bp_custom_add_notification( $comment_id, $comment_object ) {

  if ( !is_user_logged_in()){return;}
  $current_user_id = wp_get_current_user()->ID;

  $followers = jdx_get_post_follower($comment_object->comment_post_ID);
  $post = get_post( $comment_object->comment_post_ID );
	$followers[] = $post->post_author;
  

  foreach ($followers as $user_id){
    if($user_id == $current_user_id) continue;
    
    bp_notifications_add_notification( array(
      'user_id'           => $user_id,
      'item_id'           => $comment_id,
      'component_name'    => 'custom',
      'component_action'  => 'insert_comment',
      'date_notified'     => bp_core_current_time(),
      'is_new'            => 1,
    ) );
  }
	
  //do_wp_debug(__FILE__, array('bp_custom_add_notification', $followers));
}
add_action( 'wp_insert_comment', 'bp_custom_add_notification', 99, 2 );

function jdx_get_post_follower($post_id){
  //leveleage on WP Favorited Post plugin
  global $wpdb;
  
  $sql = $wpdb->prepare( "SELECT user_id FROM $wpdb->usermeta where meta_key = 'wpfp_favorites' and meta_value like '%%%s%%'", '"'.$wpdb->esc_like($post_id).'"');
  do_wp_debug(__FILE__, array($sql));

  return $wpdb->get_col($sql);
}
