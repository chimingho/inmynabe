<?php 

/**************
  * Meso
  */
function meso_load_child_style() {
global $theme_version;
wp_enqueue_style( 'meso-child-css', get_stylesheet_directory_uri() . '/style.css', array(), $theme_version );
}
add_action( 'wp_enqueue_scripts', 'meso_load_child_style',99 );  

function meso_add_custom_searchform() { 
return get_search_form();
}
add_action('bp_inside_top_nav','meso_add_custom_searchform',20);

function meso_allow_scripts() { return 'meso_sanitize_null'; }
add_filter('meso_textarea_settings_filter','meso_allow_scripts');

function meso_add_cat_desc() {
  $get_catdesc = category_description(); 
  if($get_catdesc) {
    echo $get_catdesc;
  }
}
add_action('bp_inside_headline', 'meso_add_cat_desc');
