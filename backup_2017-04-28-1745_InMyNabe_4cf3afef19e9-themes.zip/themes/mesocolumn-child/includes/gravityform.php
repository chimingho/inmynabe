<?php 
/* somehow amazon_shortcode didn't return tile. also affect {post_permlink} custom tag parsing */
//add_filter("gform_post_data", 'jdx_set_post_values', 100, 2);
function jdx_set_post_values( $post_data, $form ) {
  switch($form['id']){
    case 2: //book
      $az_rslt = amazon_shortcode('asin='.$post_data['post_custom_fields']['ASIN'].'&template=title&product=Books'); 
      if(!empty($az_rslt)){
        $post_data['post_title'] = $az_rslt;
        do_wp_debug(__FILE__, array('jdx_set_post_values', $form, $post_data,$az_rslt));
      }
      break;
    case 4: //tool
      break;
    default:
  }

    return $post_data;

}


/** sync post custom taxnomy after entry update **/
add_action( 'gform_after_update_entry', 'sync_post_to_entry', 10, 2);
function sync_post_to_entry( $form, $entry_id) {
  $entry = GFAPI::get_entry( $entry_id );
  if ( isset ( $entry['post_id'] ) ) {
    $gfcpt = new GFCPTAddonBase();
    global $gf_cpt_addon;
    $gf_cpt_addon->save_taxonomies( $entry['post_id'], $entry, $form );
  }
}

/*add_action( 'gform_after_update_entry', 'update_field_after_entry_save', 10, 3 );
function update_field_after_entry_save( $form, $entry_id, $original_entry ) {
  $entry = GFAPI::get_entry( $entry_id );
  switch($form['id']){
    case 2: //book
      $asin = rgar( $entry, '1');
      if( $asin != rgar( $original_entry, '1' )){
        $book_title = amazon_shortcode('asin='.$asin.'&template=title&product=Books'); 
        GFAPI::update_entry_property( $entry_id, '4', $book_title);
      }
      break;
    default:
  }
  do_wp_debug(__FILE__, array('update_field_after_entry_save', $entry, $original_entry));
    
  print_r( $original_entry, 1 );
    print_r( $entry, 1 );
}
*/

//add_filter( 'gform_entry_post_save', 'post_save', 10, 2 );
function post_save( $entry, $form ) {
  $entry['source_url'] = 'the new url here';
  GFAPI::update_entry_property( $entry['id'], 'source_url', $entry['source_url'] );
  return $entry;
}


add_action( 'gform_after_submission', 'redirect_on_post', 10, 2 );
function redirect_on_post($entry, $form) {
    $post_name = get_permalink($entry['post_id']);
    wp_redirect($post_name);
    exit;
}

/**
* gravity form pre submission 
*/
//add_action( 'gform_pre_submission', 'pre_submission_handler' );
//add_filter( 'gform_pre_render_2', 'pre_submission_handler' ); //didn't trigger
//add_filter( 'gform_pre_validation_2', 'pre_submission_handler' ); 
//add_filter( 'gform_admin_pre_render_2', 'pre_submission_handler' ); //didn't trigger
//add_filter( 'gform_pre_submission_filter_2', 'pre_submission_handler' );
function pre_submission_handler( $form ) {
  switch($form['id']){
    case 2: //book
      if(empty($_POST['input_4'])){
        $_POST['input_4'] = amazon_shortcode('asin='.rgpost('input_1').'&template=title&product=Books'); 
        do_wp_debug(__FILE__, array('pre_submission_handler', $form, $_POST));
      }
      break;
    case 4: //tool
      if(empty($_POST['input_4'])){
        $_POST['input_4'] = amazon_shortcode('asin='.rgpost('input_1').'&template=title'); 
        do_wp_debug(__FILE__, array('pre_submission_handler', $form, $_POST));
      }
      break;
    default:
  }
}


/**
*  gravity form comfirmation
*  setting in Dashboard isn't working due to new Wordpress version
*  after submission, redirect back
**/
function gf_custom_confirmation( $confirmation, $form, $entry, $ajax ) {
  //if( $form['id'] == '1' ) {
  $request_url = chop($_SERVER['HTTP_REFERER'], 'edit/');
  $request_url = chop($_SERVER['HTTP_REFERER'], 'new/');
  $confirmation = array( 'redirect' => $request_url); 
  //} elseif( $form['id'] == '102' ) {
  //  $confirmation = "custom_confirmation. Thanks for contacting us. We will get in touch with you soon";
  //}
  return $confirmation;
}
//add_filter( 'gform_confirmation', 'gf_custom_confirmation', 10, 4 );

add_action( 'gform_delete_lead', 'delete_entry_post' );
function delete_entry_post( $entry_id ) {

    //getting entry object
    $entry = GFAPI::get_entry( $entry_id );

    //if entry is associated with a post, delete it
    if ( isset( $entry['post_id'] ) ) {
        wp_delete_post( $entry['post_id'] );
    }
}


/**
* Gravity Wiz // Gravity Forms // Post Permalink Merge Tag
* http://gravitywiz.com
*/
class GWPostPermalink {
    
    function __construct() {
        
        add_filter('gform_custom_merge_tags', array($this, 'add_custom_merge_tag'), 10, 4);
        add_filter('gform_replace_merge_tags', array($this, 'replace_merge_tag'), 10, 3);
        
    }
    
    function add_custom_merge_tag($merge_tags, $form_id, $fields, $element_id) {
        
        if(!GFCommon::has_post_field($fields))
            return $merge_tags;
        
        $merge_tags[] = array('label' => 'Post Permalink', 'tag' => '{post_permalink}');
        
        return $merge_tags;
    }
    
    function replace_merge_tag($text, $form, $entry) {
        
        $custom_merge_tag = '{post_permalink}';
        if(strpos($text, $custom_merge_tag) === false || !rgar($entry, 'post_id'))
            return $text;
        
        $post_permalink = get_permalink(rgar($entry, 'post_id'));
        $text = str_replace($custom_merge_tag, $post_permalink, $text);
        
        return $text;
    }
    
}

new GWPostPermalink();
