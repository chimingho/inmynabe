
<?php

if (!class_exists('GFAPI')) return;

class JDX_GFAPI extends GFAPI
{
  	/**
	 * Returns the Entry object for a given Post ID
	 *
	 * @param int $entry_id The ID of the Entry
	 *
	 * @return mixed The Entry object or a WP_Error instance
	 */
	public static function get_entry_by_post_id( $post_id ) {

		$search_criteria['field_filters'][] = array( 'key' => 'post_id', 'value' => $post_id );

		$paging  = array( 'offset' => 0, 'page_size' => 1 );
		$entries = self::get_entries( 0, $search_criteria, null, $paging );

		if ( empty( $entries ) ) {
			//return new WP_Error( 'not_found', sprintf( __( 'Entry with id %s not found', 'gravityforms' ), $post_id ), $post_id );
      return null;
		}

		return $entries[0];
	}
  
  	/**
	 * Deletes a single Entry.
	 *
	 * @param int $post_id The Post ID of the Entry object
	 *
	 * @return mixed Either true for success or a WP_Error instance
	 */
	public static function delete_entry_by_post_id( $post_id ) {

		$entry = get_entry_by_post_id( $post_id );
		if ( empty( $entry ) ) {
			return new WP_Error( 'invalid_entry_id', sprintf( __( 'Invalid entry id: %s', 'gravityforms' ), $entry_id ), $entry_id );
		}
		GFFormsModel::delete_lead( $entry->entry_id );

		return true;
	}
}

?>