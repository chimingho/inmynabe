<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) )
  exit;




/******
  garden planting 
  */
function add_plant_tabs() {
  global $bp;

  require_once get_stylesheet_directory().'/includes/jdx-custom-type.php';
  $count = JDX_Custom_Type::get_posts_count('plant', bp_displayed_user_id(), 'Publish');

  bp_core_new_nav_item( array(
    'name'                  => 'Plants <span>'.$count.'</span>',
    'slug'                  => 'plants',
    'parent_url'            => $bp->displayed_user->domain,
    'parent_slug'           => $bp->profile->slug,
    'screen_function'       => 'plant_posts_screen',			
    'position'              => 400,
    'show_for_displayed_user' => false,
    'default_subnav_slug'   => 'plants'
  ) );

  bp_core_new_subnav_item( array(
    'name'              => 'Listings',
    'slug'              => 'posts',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'plants' ),
    'parent_slug'       => 'plants',
    'screen_function'   => 'plant_posts_screen',
    'position'          => 100,
    'user_has_access'   => bp_is_my_profile()
  ) );		

  bp_core_new_subnav_item( array(
    'name'              => 'New Plant',
    'slug'              => 'new',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'plants' ),
    'parent_slug'       => 'plants',
    'screen_function'   => 'plant_new_screen',
    'position'          => 150,
    'user_has_access'   => bp_is_my_profile(), 
    'link'            	=> get_page_link(394)

  ) );	

}
add_action( 'bp_setup_nav', 'add_plant_tabs', 100 );

function plant_posts_screen() {
  add_action( 'bp_template_content', 'plant_posts_content' );
  bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function plant_posts_content() { 
  echo do_shortcode('[gravityview id="184"]');
}
function plant_new_screen() {
  //add_action( 'bp_template_content', 'plant_new_content' );
  //bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function plant_new_content() {
  echo do_shortcode("[gravityform id='3' title='false' description='flase']");
}




/******
  book 
  */
function add_book_tabs() {
  global $bp;

  require_once get_stylesheet_directory().'/includes/jdx-custom-type.php';
  $count = JDX_Custom_Type::get_posts_count('book', bp_displayed_user_id(), 'Publish');

  bp_core_new_nav_item( array(
    'name'                  => 'Books <span>'.$count.'</span>',
    'slug'                  => 'books',
    'parent_url'            => $bp->displayed_user->domain,
    'parent_slug'           => $bp->profile->slug,
    'screen_function'       => 'book_posts_screen',			
    'position'              => 200,
    'show_for_displayed_user' => false,
    'default_subnav_slug'   => 'books'
  ) );

  bp_core_new_subnav_item( array(
    'name'              => 'Listings',
    'slug'              => 'posts',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'books' ),
    'parent_slug'       => 'books',
    'screen_function'   => 'book_posts_screen',
    'position'          => 100,
    'user_has_access'   => bp_is_my_profile()
  ) );		

  bp_core_new_subnav_item( array(
    'name'              => 'New Book',
    'slug'              => 'new',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'books' ),
    'parent_slug'       => 'books',
    'screen_function'   => 'book_new_screen',
    'position'          => 150,
    'user_has_access'   => bp_is_my_profile(),
    'link'            	=> get_page_link(392)
  ) );	

}
add_action( 'bp_setup_nav', 'add_book_tabs', 100 );

function book_posts_screen() {
  add_action( 'bp_template_content', 'book_posts_content' );
  bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function book_posts_content() { 
  echo do_shortcode("[gravityview id='159']");
}
function book_new_screen() {
  //add_action( 'bp_template_content', 'book_new_content' );
  //bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function book_new_content() {
  echo do_shortcode("[gravityform id='2' title='false' description='flase']");
}


/******
 service 
 */
function add_service_tabs() {
  global $bp;

  require_once get_stylesheet_directory().'/includes/jdx-custom-type.php';
  $count = JDX_Custom_Type::get_posts_count('service', bp_displayed_user_id(), 'Publish');

  bp_core_new_nav_item( array(
    'name'                  => 'Services <span>'.$count.'</span>',
    'slug'                  => 'services',
    'parent_url'            => $bp->displayed_user->domain,
    'parent_slug'           => $bp->profile->slug,
    'screen_function'       => 'service_posts_screen',			
    'position'              => 600,
    'show_for_displayed_user' => false,
    'default_subnav_slug'   => 'services'
  ) );

  bp_core_new_subnav_item( array(
    'name'              => 'Listings',
    'slug'              => 'posts',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'services' ),
    'parent_slug'       => 'services',
    'screen_function'   => 'service_posts_screen',
    'position'          => 100,
    'user_has_access'   => bp_is_my_profile()
  ) );		

  bp_core_new_subnav_item( array(
    'name'              => 'New Service',
    'slug'              => 'new',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'services' ),
    'parent_slug'       => 'services',
    'screen_function'   => 'service_new_screen',
    'position'          => 150,
    'user_has_access'   => bp_is_my_profile(),
    'link'            	=> get_page_link(396)
  ) );	

}
add_action( 'bp_setup_nav', 'add_service_tabs', 100 );

function service_posts_screen() {
  add_action( 'bp_template_content', 'service_posts_content' );
  bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function service_posts_content() { 
  echo do_shortcode('[gravityview id="190"]');
}
function service_new_screen() {
  //add_action( 'bp_template_title', 'animals_screen_title' );
  //add_action( 'bp_template_content', 'service_new_content' );
  //bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function service_new_content() {
  echo do_shortcode("[gravityform id='6' title='false' description='flase']");
}


/******
  recipe 
  */
function add_recipe_tabs() {
  global $bp;

  require_once get_stylesheet_directory().'/includes/jdx-custom-type.php';
  $count = JDX_Custom_Type::get_posts_count('recipe', bp_displayed_user_id(), 'Publish');

  bp_core_new_nav_item( array(
    'name'                  => 'Recipes <span>'.$count.'</span>',
    'slug'                  => 'recipes',
    'parent_url'            => $bp->displayed_user->domain,
    'parent_slug'           => $bp->profile->slug,
    'screen_function'       => 'recipe_posts_screen',			
    'position'              => 500,
    'show_for_displayed_user' => false,
    'default_subnav_slug'   => 'recipes'
  ) );

  bp_core_new_subnav_item( array(
    'name'              => 'Listings',
    'slug'              => 'posts',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'recipes' ),
    'parent_slug'       => 'recipes',
    'screen_function'   => 'recipe_posts_screen',
    'position'          => 100,
    'user_has_access'   => bp_is_my_profile()
  ) );		

  bp_core_new_subnav_item( array(
    'name'              => 'New Recipe',
    'slug'              => 'new',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'recipes' ),
    'parent_slug'       => 'recipes',
    'screen_function'   => 'recipe_new_screen',
    'position'          => 150,
    'user_has_access'   => bp_is_my_profile(), 
    'link'            	=> get_page_link(395)
  ) );	

}
add_action( 'bp_setup_nav', 'add_recipe_tabs', 100 );

function recipe_posts_screen() {
  //add_action( 'bp_template_title', 'animals_screen_title' );
  add_action( 'bp_template_content', 'recipe_posts_content' );
  bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function recipe_posts_content() { 
  //do_wp_debug(__FILE__, array('recipe_posts_content', current_user_can( 'edit_others_posts' ), bp_is_user(), bp_displayed_user_id(),  bp_loggedin_user_id()));

//  if((bp_displayed_user_id()==bp_loggedin_user_id()) || current_user_can('edit_others_posts') ){
      echo do_shortcode('[gravityview id="32"]');
//    }
//    else{
//      $paged = bp_action_variable( 1 );
//      $paged = $paged ? $paged : 1;
//      
//      $query_args = array(
//        'author'        => bp_displayed_user_id(),
//        'post_type'     => 'recipe',
//        'post_status'   => 'any',
//            'orderby'       => 'post_date',
//            'order'         => 'DESC',
//            'paged'         => intval( $paged )
//        );
//      query_posts( $query_args );
//          get_template_part( 'content', 'recipe' );
//      wp_reset_postdata();
//      wp_reset_query();
//    } 

}
function recipe_new_screen() {
  //add_action( 'bp_template_title', 'animals_screen_title' );
  //add_action( 'bp_template_content', 'recipe_new_content' );
  //bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function recipe_new_content() {
  //$_POST["edit_id"]= 1;  
  echo do_shortcode("[gravityform id='1' title='false' description='flase']");
}



/******
  tool 
  */
function add_tool_tabs() {
  global $bp;

  require_once get_stylesheet_directory().'/includes/jdx-custom-type.php';
  $count = JDX_Custom_Type::get_posts_count('tool', bp_displayed_user_id(), 'Publish');

  bp_core_new_nav_item( array(
    'name'                  => 'Tools <span>'.$count.'</span>',
    'slug'                  => 'tools',
    'parent_url'            => $bp->displayed_user->domain,
    'parent_slug'           => $bp->profile->slug,
    'screen_function'       => 'tool_posts_screen',			
    'position'              => 700,
    'show_for_displayed_user' => false,
    'default_subnav_slug'   => 'tools'
  ) );

  bp_core_new_subnav_item( array(
    'name'              => 'Listings',
    'slug'              => 'posts',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'tools' ),
    'parent_slug'       => 'tools',
    'screen_function'   => 'tool_posts_screen',
    'position'          => 100,
    'user_has_access'   => bp_is_my_profile()
  ) );		

  bp_core_new_subnav_item( array(
    'name'              => 'New Tool',
    'slug'              => 'new',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'tools' ),
    'parent_slug'       => 'tools',
    'screen_function'   => 'tool_new_screen',
    'position'          => 150,
    'user_has_access'   => bp_is_my_profile(), 
    'link'            	=> get_page_link(397)
  ) );	

}
add_action( 'bp_setup_nav', 'add_tool_tabs', 100 );

function tool_posts_screen() {
  add_action( 'bp_template_content', 'tool_posts_content' );
  bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function tool_posts_content() { 
  echo do_shortcode('[gravityview id="186"]');
}
function tool_new_screen() {
  //add_action( 'bp_template_title', 'animals_screen_title' );
  //add_action( 'bp_template_content', 'tool_new_content' );
  //bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function tool_new_content() {
  //$_POST["edit_id"]= 1;  
  echo do_shortcode("[gravityform id='4' title='false' description='flase']");
}



/******
  club 
  */
function add_club_tabs() {
  global $bp;

  require_once get_stylesheet_directory().'/includes/jdx-custom-type.php';
  $count = JDX_Custom_Type::get_posts_count('club', bp_displayed_user_id(), 'Publish');

  bp_core_new_nav_item( array(
    'name'                  => 'Clubs <span>'.$count.'</span>',
    'slug'                  => 'clubs',
    'parent_url'            => $bp->displayed_user->domain,
    'parent_slug'           => $bp->profile->slug,
    'screen_function'       => 'club_posts_screen',			
    'position'              => 300,
    'show_for_displayed_user' => false,
    'default_subnav_slug'   => 'clubs'
  ) );

  bp_core_new_subnav_item( array(
    'name'              => 'Listings',
    'slug'              => 'posts',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'clubs' ),
    'parent_slug'       => 'clubs',
    'screen_function'   => 'club_posts_screen',
    'position'          => 100,
    'user_has_access'   => bp_is_my_profile()
  ) );		

  bp_core_new_subnav_item( array(
    'name'              => 'New Club',
    'slug'              => 'new',
    'parent_url'        => trailingslashit( bp_displayed_user_domain() . 'clubs' ),
    'parent_slug'       => 'clubs',
    'screen_function'   => 'club_new_screen',
    'position'          => 150,
    'user_has_access'   => bp_is_my_profile(),
    'link'            	=> get_page_link(393)

  ) );	

}
add_action( 'bp_setup_nav', 'add_club_tabs', 100 );

function club_posts_screen() {
  add_action( 'bp_template_content', 'club_posts_content' );
  bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function club_posts_content() { 
  echo do_shortcode('[gravityview id="188"]');
}
function club_new_screen() {
  //add_action( 'bp_template_title', 'animals_screen_title' );
  //add_action( 'bp_template_content', 'club_new_content' );
  //bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}
function club_new_content() {
  //$_POST["edit_id"]= 1;  
  echo do_shortcode("[gravityform id='5' title='false' description='flase']");
}
