<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) )
  exit;


function gv_check_entry_display( $check_entry_display ) {
  return false;
}
add_filter( 'gravityview/common/get_entry/check_entry_display', 'gv_check_entry_display', 10, 4 );

/**
 * Change the update entry success message, including the link
 * 
 * @param $message string The message itself
 * @param $view_id int View ID
 * @param $entry array The Gravity Forms entry object
 * @param $back_link string Url to return to the original entry
 */
function gv_my_update_message( $message, $view_id, $entry, $back_link ) {
  //do_wp_debug(__FILE__, array('gv_my_update_message', $message, $view_id, $entry, $back_link));

  $permalink_esc = bp_loggedin_user_domain();
  switch ($view_id) {
    case 32:
        $permalink_esc .= 'recipes';
        break;
    case 159:
        $permalink_esc .= 'books';
        break;
    case 184:
        $permalink_esc .= 'plants';
        break;
    case 186:
        $permalink_esc .= 'tools';
        break;
    case 188:
        $permalink_esc .= 'clubs';
        break;
    case 190:
        $permalink_esc .= 'services';
        break;
    default:
  }
  $permalink_esc = esc_url( $permalink_esc);

  return 'Entry Updated. <a href="'.$permalink_esc.'">Return to the list</a>';
}
//add_filter( 'gravityview/edit_entry/success', 'gv_my_update_message', 10, 4 );


add_action( 'gravityview/edit_entry/after_update', 'gravityview_redirect_after_update', 5, 2 );
function gravityview_redirect_after_update( $form, $entry_id ) {
    // Get the current View ID
    $view_id = GravityView_View::getInstance()->getViewId();
    
    // Get the link to the View
    //$permalink_esc = esc_url( get_permalink( $view_id ) );
  $permalink_esc = bp_loggedin_user_domain();
  switch ($view_id) {
    case 32:
        $permalink_esc .= 'recipes';
        break;
    case 159:
        $permalink_esc .= 'books';
        break;
    case 184:
        $permalink_esc .= 'plants';
        break;
    case 186:
        $permalink_esc .= 'tools';
        break;
    case 188:
        $permalink_esc .= 'clubs';
        break;
    case 190:
        $permalink_esc .= 'services';
        break;
    default:
  }
    $permalink_esc = esc_url( $permalink_esc);
    ?>
    <script>
        jQuery(document).ready( function() {
            window.location.replace( "<?php echo $permalink_esc; ?>" );
        });
    </script>
    <?php

}

/**
 * Customise the cancel button link
 *
 * @param $back_link string
 *
 * since 1.11.1
 */
function gv_my_edit_cancel_link( $back_link, $form, $entry, $view_id ) {
  return chop($_SERVER['HTTP_REFERER'], 'edit/');
  //return str_replace( 'entry/'.$entry['id'].'/', '', $back_link );
}
add_filter( 'gravityview/edit_entry/cancel_link', 'gv_my_edit_cancel_link', 10, 4 );


/**
 * Enable custom class for GravityView widgets. Requires GravityView 1.5.4 or higher.
 * 
 * @param boolean False by default. Return true if you want to enable.
 * @param GravityView_Widget Current instance of GravityView_Widget
 */
//add_filter('gravityview/widget/enable_custom_class', '__return_true' );