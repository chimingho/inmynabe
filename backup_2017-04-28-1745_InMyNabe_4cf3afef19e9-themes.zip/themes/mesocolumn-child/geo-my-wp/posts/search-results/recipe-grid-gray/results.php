<?php 
if(SINGLE_POST_CUSTOM)
{
	global $entry;
	require_once get_stylesheet_directory().'/includes/jdx-gfapi-extend.php';
}
/**
 * Posts locator "grid-gray" search results template file. 
 * 
 * The information on this file will be displayed as the search results.
 * 
 * The function pass 2 args for you to use:
 * $gmw  - the form being used ( array )
 * $post - each post in the loop
 * 
 * You could but It is not recomemnded to edit this file directly as your changes will be overridden on the next update of the plugin.
 * Instead you can copy-paste this template ( the "grid-gray" folder contains this file and the "css" folder ) 
 * into the theme's or child theme's folder of your site and apply your changes from there. 
 * 
 * The template folder will need to be placed under:
 * your-theme's-or-child-theme's-folder/geo-my-wp/posts/search-results/
 * 
 * Once the template folder is in the theme's folder you will be able to choose it when editing the posts locator form.
 * It will show in the "Search results" dropdown menu as "Custom: grid-gray".
 */
?>
<!--  Main results wrapper - wraps the paginations, map and results -->
<div class="gmw-results-wrapper gmw-results-wrapper-<?php echo $gmw['ID']; ?> gmw-pt-grid-gray-results-wrapper">
  <div class="float-right"><?php //echo do_shortcode('[sc name="az_kitchen_468x60_1"]'); ?></div>

	<?php do_action( 'gmw_search_results_start' , $gmw, $post ); ?>
	
	<!-- results count -->
	<div class="results-count-wrapper">
		<p>
    <?php gmw_per_page( $gmw, $gmw['total_results'], 'paged' ); ?><?php gmw_pagination( $gmw, 'paged', $gmw['max_pages'] ); ?>
		<?php gmw_results_message( $gmw, false ); ?>
    </p>
	</div>
	
	<?php do_action( 'gmw_search_results_before_top_pagination' , $gmw, $post ); ?>
	
  <?php
	//<div class="pagination-per-page-wrapper top">
		//<!--  paginations -->
	//</div> 
    ?>	
	 <!-- GEO my WP Map -->
    <?php 
    if ( $gmw['search_results']['display_map'] == 'results' ) {
        gmw_results_map( $gmw );
    }
    ?>
		
	<?php do_action( 'gmw_search_results_before_loop' , $gmw, $post ); ?>
	
	<!--  Results wrapper -->
	<ul class="posts-list-wrapper">

		<?php while ( $gmw_query->have_posts() ) : $gmw_query->the_post(); ?>
		
			<?php $featured = ( !empty( $post->feature ) ) ? 'gmw-featured-post' : ''; ?>

			<li id="post-<?php the_ID(); ?>" <?php post_class( 'single-post '.$featured ); ?>>
				
				<div class="wrapper-inner">
				
					<?php do_action( 'gmw_search_results_loop_item_start' , $gmw, $post ); ?>
				
										
					<div class="post-content">
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
						<?php if ( isset( $gmw['search_results']['featured_image']['use'] ) ) { ?>
							
							<?php do_action( 'gmw_posts_loop_before_image', $gmw, $post ); ?>
													
							<?php if ( has_post_thumbnail() ) { ?>
								<div class="post-thumbnail">
									<?php the_post_thumbnail( array( $gmw['search_results']['featured_image']['width'], $gmw['search_results']['featured_image']['height'] ) ); ?>
								</div>
							<?php } else { ?>
								<i class="fa fa-picture-o no-post-thumbnail"></i>
							<?php } ?>
							
						<?php } ?>
						
					<!-- Title -->
					<div class="top-wrapper">	
						<h2 class="post-title">

<?php if(SINGLE_POST_CUSTOM){ 
                $entry = JDX_GFAPI::get_entry_by_post_id(get_the_id());
                if(isset($entry)){
                  echo do_shortcode('[gv_entry_link entry_id="'.$entry['id'].'" view_id="32"]'.get_the_title().'[/gv_entry_link]'); 
                }
}else{ ?>
								<?php the_title(); ?> 
<?php } ?>


						</h2>
					</div>
					</a>
            
            <!--  Excerpt -->
						<?php if ( isset( $gmw['search_results']['excerpt']['use'] ) ) { ?>
						
							<?php do_action( 'gmw_posts_loop_before_excerpt', $gmw, $post ); ?>
							
							<div class="excerpt">
								<?php //gmw_excerpt( $post, $gmw, $post->post_excerpt, $gmw['search_results']['excerpt']['count'], $gmw['search_results']['excerpt']['more'] ); ?>
								<?php //gmw_excerpt( $post, $gmw, $post->post_content, $gmw['search_results']['excerpt']['count'], $gmw['search_results']['excerpt']['more'] ); ?>
							</div>
						<?php } ?>
				
			    		<!--  Addiotional info -->
                        <?php if ( !empty( $gmw['search_results']['additional_info'] ) ) { ?>
    
					    	<?php do_action( 'gmw_search_results_before_contact_info', $post, $gmw ); ?>
						   	
						   	<div class="contact-info">
								<h4><?php echo $gmw['labels']['search_results']['contact_info']['contact_info']; ?></h4>
					    		<?php gmw_additional_info( $post, $gmw, $gmw['search_results']['additional_info'], $gmw['labels']['search_results']['contact_info'], 'ul' ); ?> 
					    	</div>
					    <?php } ?>
			    			
			    		<?php if ( !empty( $gmw['search_results']['opening_hours'] ) ) { ?>
    
					    	<?php do_action( 'gmw_search_results_before_opening_hours', $post, $gmw ); ?>
						   	
					    	<div class="opening-hours">
					    		<?php gmw_pt_days_hours( $post, $gmw ); ?>
					    	</div>
					    <?php } ?>
					    
			    		<?php gmw_pt_taxonomies( $gmw, $post ); ?>
              <div>
                <?php
                echo do_shortcode("[jdx_bp func='avatar' user_id=".$post->post_author." submenu='recipes']") ;     
                if(is_user_logged_in()){
                  $user_info = get_userdata($post->post_author);
                  echo bpfr_pm_link($user_info->user_login, 'Inquery recipe -- '. $post->post_title, null);  
                } ?>           
              </div>
		   			</div>
		   			
		   			<?php do_action( 'gmw_posts_loop_before_bottom_wrapper' , $gmw, $post ); ?>
		   			
		   			<div class="bottom-wrapper">
						<!-- Get directions -->	
		   				<?php if ( isset( $gmw['search_results']['get_directions'] ) ) { ?>
		   				
		   					<?php do_action( 'gmw_search_results_before_get_directions', $post, $gmw ); ?>
		   					<!--  Address -->
	                        <div class="get-directions-wrapper">
			    				<span class="fa fa-map-marker address-icon"></span>
    							<?php gmw_directions_link( $post, $gmw, $post->address ); ?>
		    				</div>
			    		<?php } else { ?>
			    			 <!--  Address -->
	                        <div class="address-wrapper">
						    	<span class="fa fa-map-marker address-icon"></span>
						    	<span class="wppl-address"><?php gmw_location_address( $post, $gmw ); ?></span>
						    </div>
		    		  	<?php  } ?>
		    			
						<!--  Driving Distance -->
						<?php if ( isset( $gmw['search_results']['by_driving'] ) ) { ?>
		    				<?php gmw_driving_distance( $post, $gmw, false ); ?>
		    			<?php } ?>
		    		</div>
	    			
	    			<?php do_action( 'gmw_search_results_loop_item_end', $gmw, $post ); ?>
	    		</div>
				
			</li><!-- #post -->
		
		<?php endwhile;	 ?>
	</ul>
	
	<?php do_action( 'gmw_search_results_after_loop' , $gmw, $post ); ?>
	
	<div class="pagination-per-page-wrapper bottom">
		<!--  paginations -->
		<?php gmw_per_page( $gmw, $gmw['total_results'], 'paged' ); ?><?php gmw_pagination( $gmw, 'paged', $gmw['max_pages'] ); ?>
	</div> 
	
	<?php do_action( 'gmw_search_results_end' , $gmw, $post ); ?>
	
</div> <!-- output wrapper -->
<?php echo do_shortcode('[sc name="az_recipe_product"]'); ?>

