<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) )
  exit;

const CPTs = array('club', 'book', 'plant', 'recipe', 'tool', 'service');

/**
* WP_DEBUG
*/
function do_wp_debug($file, $vars=[]){
  if(WP_DEBUG)
  {
    //debug_print_backtrace();
    echo '<pre>'.htmlspecialchars(print_r($file, true)).'</pre>';
    foreach($vars as $var){
      echo '<pre>'.htmlspecialchars(print_r($var, true)).'</pre>';
    }
  }
}

//add_filter( 'posts_request', 'dump_post_request' );
function dump_post_request( $input ) {
  do_wp_debug(__FILE__, array('dump_post_request', $input));
  return $input;
}


/**
 * Alter different parts of the query
 * 
 * @param array $pieces
 * 
 * @return array $pieces
 */
//add_filter( 'posts_clauses', 'intercept_query_clauses', 20, 1 );
function intercept_query_clauses( $pieces )
{
	echo '<style>#post-clauses-dump { display: block; background-color: #777; color: #fff; white-space: pre-line; }</style>';
	// >>>> Inspect & Debug the Query 
	// NEVER EVER show this to anyone other than an admin user - unless you're in your local installation
	if ( current_user_can( 'manage_options' ) )
	{
		$dump = var_export( $pieces, true );
		echo "< PRE id='post-clauses-dump'>{$dump}</ PRE >";
	}

	return $pieces;
}


/**
* add BP profile custom tab
* https://gist.github.com/shanebp/5d3d2f298727a0a036e5
*/
require_once get_stylesheet_directory().'/includes/bp-tab.php';
require_once get_stylesheet_directory().'/includes/bp-notification-custom.php';
require_once get_stylesheet_directory().'/includes/gravityform.php';
require_once get_stylesheet_directory().'/includes/gravityview.php';
require_once get_stylesheet_directory().'/includes/gmw.php';
require_once get_stylesheet_directory().'/includes/theme-specific.php';
require_once get_stylesheet_directory().'/includes/wp-core-custom.php';




/********
* post_type:
* asin: book isbn/amazon asin  
* template: 
*/
function get_amazon_product_template($atts=[], $content = null, $tag='') {
  
  $atts = array_change_key_case((array)$atts, CASE_LOWER);
  $wporg_atts = shortcode_atts([
    'asin' => '',
    'template' => '',
    'post_type' => 'book'], $atts, $tag);

  $asin = $wporg_atts['asin'];
  $template = $wporg_atts['template'];
  $post_type = $wporg_atts['post_type'];  
  
  if( $post_type == 'book') {  
    if(strlen($asin) <= 10){
      $r =  amazon_shortcode('asin='.$asin.'&template='.$template.'&product=Book');  
    }else{
      $styleSheetDir = get_stylesheet_directory();
      require_once $styleSheetDir.'/includes/Biblys/Isbn/Isbn.php';
      require_once $styleSheetDir.'/includes/Biblys/Isbn/Ranges.php';
      require_once $styleSheetDir.'/includes/Biblys/Isbn/ranges-array.php';

      $isbn = new Biblys\Isbn\Isbn($asin);
      if ($isbn->isValid() ){
        $r = amazon_shortcode('asin='.$isbn->format('ISBN-10').'&template='.$template.'&product=Books'); 
      } else {
        $r = 'false';
      }
    }
  }else{
			$r = amazon_shortcode('asin='.$asin.'&template='.$template); 
  }
  
  //do_wp_debug(__FILE__, array('get_amazon_product_template', $r));
  return $r; 
}
add_shortcode( 'book', 'get_amazon_product_template' );


/**
* create taxonomy by code  
* https://codex.wordpress.org/Function_Reference/register_post_type
* https://codex.wordpress.org/Function_Reference/register_taxonomy
* currently custom tax was managed by a plugin
*/


add_action( 'xprofile_updated_profile', 'SaveEditsRedirect', 12 );
function SaveEditsRedirect() {
  global $bp;
  wp_redirect( $bp->loggedin_user->domain );
  exit;
}
/**
* get BP profile meta
*/
//add_action( 'bp_profile_header_meta', 'display_user_color_pref' );
//function display_user_color_pref() {
//    echo 'I choose this color: ';
//    $args = array(
//        'field'   => 2, // Integers do not need to be enclosed in quotes.
//        );
//    bp_profile_field_data( $args );
//}
//function display_user_color_pref() {
//    echo 'I choose this color: ';
//    $args = array(
//        'field'   => 'Favorite Color', // Field name or ID.
//        );
//    bp_profile_field_data( $args );
//}  




/* gravityview show text label
*/
//add_filter( 'gravityview/fields/select/output_label', '__return_true' );
/*add_filter( 'gravityview/fields/select/output_label', 'gv_my_form_dropdown_output_label', 10, 3 );
function gv_my_form_dropdown_output_label( $show_label, $entry, $field ) {
	if( !empty( $entry['form_id'] ) && MY_FORM_ID == $entry['form_id'] ) {
		return true;
	}
	return $show_label;
}
add_filter( 'gravityview/fields/select/output_label', 'gv_my_view_dropdown_output_label', 10, 3 );
function gv_my_view_dropdown_output_label( $show_label, $entry, $field ) {
	if( function_exists( 'gravityview_get_view_id' ) && MY_VIEW_ID == gravityview_get_view_id() ) {
		return true;
	}
	return $show_label;
}*/


/**
 * Jetpack Contact Form Custom Redirections.
 *
 * @param  string $redirect Post submission URL.
 * @param  int    $id       Contact Form ID.
 * @param  int    $post_id  Post ID.
 *
 * @return string $redirect Custom Post submission URL.
 */
function jetpackcom_custom_form_redirect( $redirect, $id, $post_id ) {
    /**
     * Create a list of pages where you've inserted forms.
     * For each contact Form ID (found via the id attribute on the form),
     * set up a custom URL where the user will be redirected.
     */
    /* 
    $redirects = array(
        '1370' => home_url( 'page_on_your_site' ),
        '2239' => home_url( 'another_page' ),
        '1370' => home_url( 'page_on_your_site' ),
    );
    */
 
    // Let's loop though each custom redirect.
    /*
    foreach ( $redirects as $origin => $destination ) {
        if ( $id == $origin ) {
            return $destination;
        }
    }
    */
    // Default Redirect for all the other forms.
    return home_url( '/' );
}
add_filter( 'grunion_contact_form_redirect_url', 'jetpackcom_custom_form_redirect', 10, 3 );


function jeherve_custom_fb_app_id() {
    return '120460821762786'; 
}
add_filter( 'jetpack_sharing_facebook_app_id', 'jeherve_custom_fb_app_id' );