<?php 
  $uid = get_query_var( 'author');
  if(empty($uid)){ $uid = bp_displayed_user_id(); } 
  if(empty($uid)){ $uid = get_the_author_meta( 'ID' );} 
?>

<?php //if(!empty($uid)) { ?>
  <div>
    <?php $author_link = get_author_posts_url($uid); //bp_core_get_userlink(get_the_author_meta('ID'), false, true); ?>
    <div class="jdx-btn btn-book"><?php echo '<a href="'.$author_link.'?post_type=book">Owner\'s Books</a>'; ?></div>
    <div class="jdx-btn btn-club"><?php echo '<a href="'.$author_link.'?post_type=club">Owner\'s Clubs</a>'; ?></div>
    <div class="jdx-btn btn-plant"><?php echo '<a href="'.$author_link.'?post_type=plant">Owner\'s Plants</a>'; ?></div>
    <div class="jdx-btn btn-recipe"><?php echo '<a href="'.$author_link.'?post_type=recipe">Owner\'s Recipes</a>'; ?></div>
    <div class="jdx-btn btn-service"><?php echo '<a href="'.$author_link.'?post_type=service">Owner\'s Services</a>'; ?></div>
    <div class="jdx-btn btn-tool"><?php echo '<a href="'.$author_link.'?post_type=tool">Owner\'s Tools</a>'; ?></div>  
  </div>
<?php //} ?>