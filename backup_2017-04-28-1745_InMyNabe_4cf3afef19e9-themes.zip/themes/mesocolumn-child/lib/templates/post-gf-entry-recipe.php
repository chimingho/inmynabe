<?php 
$Number_of_people=13;
$Preparation_time=14;
$Cooking_time=15;
$field_ingridents_id = 3;
$field_instruction_id = 17;
require_once get_stylesheet_directory().'/includes/jdx-gfapi-extend.php';

  $entry = JDX_GFAPI::get_entry_by_post_id(get_the_id());
//  if(isset($entry)){
//    $values = maybe_unserialize($entry[17]);
//    do_wp_debug(__FILE__, array($entry, $post));
//  }
?>

<!-- recipe meta -->
<div class="recipe-tag">
  <ul id="recipe-meta">
    <?php if(!empty($entry[$Preparation_time])){ ?><li class="recipe-icon-preparation"><strong>Prep Time:</strong> <?php echo floor($entry[$Preparation_time] / 60).'h '.($entry[$Preparation_time] % 60).'m';?></li><?php } ?>
    <?php if(!empty($entry[$Cooking_time])){ ?><li class="recipe-icon-cooking"><strong>Cook Time:</strong> <?php  echo floor($entry[$Cooking_time] / 60).'h '.($entry[$Cooking_time] % 60).'m'; ?></li><?php } ?>
    <?php if(!empty($entry[$Number_of_people])){ ?><li class="recipe-icon-people"><strong>Servings:</strong> <?php echo $entry[$Number_of_people]; ?></li><?php } ?>
  </ul>
</div>

<!-- ingridents -->
<?php if(!empty($entry[$field_ingridents_id])){ ?>
<div class="recipe-content recipe-ingridents">
  <label><h3>Ingridents</h3></label>
  <ul>
  <?php 
      $values = maybe_unserialize($entry[$field_ingridents_id]);
      foreach($values as $item){
        echo '<li>'.$item.'</li>';
      }
    ?>
  </ul>
</div>
<?php } ?>


<!-- instructions -->
<?php if(!empty($entry[$field_instruction_id])){ ?>
<div class="recipe-content recipe-instruction">
  <label><h3>Directions</h3></label>
  <ul>
  <?php 
      $values = maybe_unserialize($entry[$field_instruction_id]);
      foreach($values as $item){
        echo '<li>'.$item.'</li>';
      }
    ?>
  </ul>
</div>
<?php } ?>
