<?php
// add sidebar left
function dez_add_sidebar_left() { ?>
<div id="left-sidebar" class="sidebar">
<div class="sidebar-inner">
<div class="widget-area the-icons">
<?php if ( is_active_sidebar( 'left-sidebar' ) ) : ?>
<?php dynamic_sidebar( 'left-sidebar' ); ?>
<?php else: ?>
<aside class="widget">
<h3 class="widget-title"><?php _e('Left Sidebar Widget', TEMPLATE_DOMAIN); ?></h3>
<div class="textwidget">
<?php printf( __( 'This is a widget area for %1$s. You need to setup your widget item in <a href="%2$s">here</a>', TEMPLATE_DOMAIN ), 'left sidebar',admin_url('widgets.php') ); ?>
</div>
</aside>
<?php endif; ?>
</div>
</div><!-- SIDEBAR-INNER END -->
</div><!-- LEFT SIDEBAR END -->
<?php }

// add sidebar left style
function dez_add_sidebar_left_style() {
$main_color = get_theme_mod('main_color');
print "<style type='text/css' media='all'>"; ?>
#custom #post-entry {float: right;width: 72%;}
#custom #left-sidebar {padding:10px 0 0;float: left;width: 25%;}
#left-sidebar .widget-area aside ul:first-of-type {width: 100%;padding: 0;}
#left-sidebar .widget-area aside li a:hover {color:<?php echo $main_color; ?>;}
#left-sidebar h3.widget-title {padding: 0% 0% 10px;font-size: 1.25em;margin: 0px 0px 0.5em;float: left;width: 100%;text-transform: capitalize;border-bottom: 5px solid <?php echo $main_color; ?>;background:transparent none;border-radius:0;}
<?php print "</style>";
}

function dez_add_bpp_call() {
global $in_bbpress, $bp_active;
if( is_page_template('page-templates/template-full-width.php') || $in_bbpress == 'true' || ( $bp_active == 'true' && function_exists('bp_is_blog_page') && !bp_is_blog_page() ) ) {
} else {
add_action('bp_after_blog_home','dez_add_sidebar_left');
add_action('wp_head','dez_add_sidebar_left_style');
}
}
add_action('wp','dez_add_bpp_call');

// add sidebar left widget
function dez_add_sidebar_left_widget() {
 register_sidebar(array(
    'name'=>__('Left Sidebar', TEMPLATE_DOMAIN),
    'id' => 'left-sidebar',
	'description' => __( 'Left sidebar widget area', TEMPLATE_DOMAIN ),
	'before_widget' => '<aside id="%1$s" class="widget %2$s">',
	'after_widget' => '</aside>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>',
	));
}
add_action( 'widgets_init', 'dez_add_sidebar_left_widget',10 );

?>