Theme CSS, JS, IMAGES and Resources License and Copyright:

Mesocolumn WordPress theme is under the GPL Open Sources license: http://www.gnu.org/licenses/gpl.html
Copyright (C) 2013 Dezzain.com - http://www.dezzain.com/wordpress-themes/mesocolumn/

The Font Awesome font under the SIL Open Font License: http://scripts.sil.org/OFL.
Font Awesome CSS, LESS, and SASS files are under the MIT License: http://www.opensource.org/licenses/mit-license.php
Copyright (C) 2013 Dave Gandy - http://fontawesome.io
 
John Design's SmoothGallery is under the MIT and GPL licenses: http://www.opensource.org/licenses/mit-license.php, http://www.gnu.org/licenses/gpl.html
Copyright (C) 2005 Jonathan Schemoul - http://smoothgallery.jondesign.net

Modernizr is under MIT and BSD licenses: http://www.opensource.org/licenses/mit-license.php, http://opensource.org/licenses/BSD-2-Clause
Copyright (C) 2009 Modernizr Creator and Developers - http://modernizr.com/

Superfish-menu is under MIT and GPL licenses: http://www.opensource.org/licenses/mit-license.php, http://www.gnu.org/licenses/gpl.html
Copyright (C) 2007 Joeld Birch - https://github.com/joeldbirch/superfish

Tabber is license under MIT Open Sources license: http://www.opensource.org/licenses/mit-license.php
Copyright (C) 2006 Patrick Fitzgerald - http://www.barelyfitz.com/projects/tabber/

Color picker is under the MIT and GPL licenses: http://www.opensource.org/licenses/mit-license.php, http://www.gnu.org/licenses/gpl.html
Copyright (C) 2008 Stefan Petre - http://www.eyecon.ro/colorpicker/

Uniform jQuery is under MIT License: http://www.opensource.org/licenses/mit-license.php
Copyright (C) 2008 Josh Pyles - http://uniformjs.com/

Social icons and mini icons are under GPL and open source compatible MIT licenses: http://www.opensource.org/licenses/mit-license.php, http://www.gnu.org/licenses/gpl.html
Copyright (C) 2013 Elegantthemes.com 
- http://www.elegantthemes.com/blog/resources/elegant-themes-icon-pack-for-free
- http://www.elegantthemes.com/blog/resources/beautiful-free-social-media-icons